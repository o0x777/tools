FUNC_PULG=dict()
def func(function):#做一个装饰器让字典自动生成  让定义的名字与函数名对应
	def set_func(func):
		FUNC_PULG[function]=func
	return set_func
@func("help")
def help():
	pass

@func("MessageBox")
def Message_Box():
	# server.sendto(cmd.encode("utf-8"), (self.ip, 5555))
	#text=input("请输入弹出文本:")
	return 'MessageBox'
@func("system")
def system_os():
	return 'system'#这是穿过去要执行的函数

def start(cmd):
	if cmd in FUNC_PULG:
		return FUNC_PULG[cmd]()
	else:
		return cmd

