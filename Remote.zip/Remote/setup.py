from distutils.core import setup
import py2exe
setup(console=["Client.py"])


pyinstaller Client.py -p mysql.py -p other.py --hidden-import mysql --hidden-import other